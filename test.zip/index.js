_c.component( {
    type: "testComp",
    initialize: function( data, arg, el ) {
        console.log( "initialize" );
    }
} );